import FooterComponent from "../../components/footer";

const ErrorPage = () => {
  return (
    <>
      <FooterComponent />
      <div className="ctn">
        <h1>Esta pagina aun esta en construcción</h1>
      </div>
    </>
  );
};

export default ErrorPage;
