# Readme acerca de SALUDCERCA

# Acerca del proyecto

El proyecto se centra en un acercamiento entre enfermeros profecionales que puedan ofrecer sus servicios de forma mas directa al cliente tener una alcance mas grande con los mismo y un canal de comunicación privado, poder ser evaluados por sus clientes y tener mas salida laboral en su campo y poder destacar en el mercado, se presentan sección de
**acerca de nosotros** en el cual damos una descripción breve sobre el proyecto en la pagina web.
**Enfermeros** Domde mpstramos una lista de los enfermeros que han completado el onboarding de registro del mismo poniendo su area de especialidad y los servicios que ofrece
**Unete al equipo** Para invitar a más enfermeros a registrarse y que puedan ofrecer su servicios
**Registro** Tanto para clientes como para enfermeros
**Login** Ingreso a la plataforma
**Crud** Sección en la cual se puden agregar mas servicios que puede ofrecer un enfermero areas y manejar enfermeros y clientes

# Como levantarlo en local

> [!NOTE]
>
> - **Iniciar el server en nodejs primero para evitar usar otro puerto el front esta preparado para solicitar al puerto 3000**

**api**

1. Desplazar a la carpeta api

```bash
cd api
```

2. Instalar los modulos

```bash
npm install
```

3. Levantar el proyecto

```bash
npm start
```

**front**

1. En otro pestana line command ubicarse en la carpeta front 

```bash
cd front
```

2. Instalar los modulos

```bash
npm install -f 
```
> [!NOTE]
>
> - **Si se obtiene un error en la primera instalar volver a utilizar el commando anterior**

3. Levantar el proyecto

```bash
npm start
```

4. Preguntara si quieres usar otro puerto le damos sí.